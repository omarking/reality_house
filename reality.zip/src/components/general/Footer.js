import React from "react";

export const Footer = () => {
  return (
    <Footer>
      <h2>Footer</h2>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi soluta
        voluptates iure repudiandae porro id vero quod veniam quas in.
      </p>
    </Footer>
  );
};
