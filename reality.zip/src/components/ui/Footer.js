import React from 'react'

const Footer = () => {
    return (
        <footer className="mt-4 color-components" style={{height: '150px'}} >
            
        </footer>
    )
}

export default Footer
